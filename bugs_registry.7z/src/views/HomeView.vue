<!--HTML e CSS Retirado do site: https://codepen.io/joanarnrodrigues/pen/vYpxGJM-->
<!--Conteudo Retirado do site: https://www.birdsandblooms.com/  e  https://www.gardendesign.com/-->
<script>

export default {
  name: 'HomeView',
  data: () => ({
    bugs: JSON.parse(localStorage.getItem('bugs_registry') || '[]')
  }),
  watch: {
    bugs: {
      deep: true
    }
  },
}
</script>

<template>
  <h2 v-if="error">{{error}}</h2>       
  <section v-if="bugs && bugs.length" style="display:flex; flex-wrap: wrap;">
    <div class="mini-card" v-for="bug of bugs" :key="bug.name">
      <p><b>Scientific Name: </b>{{ bug.latinName }}</p>
      <p><b>Name: </b>{{ bug.name }}</p>
      <p><b>Taste: </b> {{ bug.taste }}% Awful</p>
      <p v-if="bug.flight">It flies!</p>
      <p v-if="bug.swim">It swims!</p>
    </div>
  </section>

  <!-- About Section   -->  
  <section id="about">
    <div class="container">
      <div class="row">
        <h1>About</h1>
        <div class="block"></div>
          <p><b>The Bugs and Birds Friendly Garden</b></p>
        </div>
        <div class="row">
          <div class="six columns">
            <h3><span class="typcn typcn-device-desktop icon"></span>Our Mission</h3>
            <p>We are team of talented botanists and gardeners, here to help you make your Friendly Garden a reality with these gardening tips and ideas!</p>
            <p>Everything we do and say is because we care about plants, quality, service, the planet and people. Because of this we like to share information about plants, growing and gardening. Inspiration from our customers and fellow gardeners is important to us and most welcome.</p>
            <img src="https://www.birdsandblooms.com/wp-content/uploads/2020/09/BNBbyc19_elise-marks-1.jpg?resize=696,696" width="450" height="300" alt=""/>
          </div>
          <div class="six columns">
            <h3><span class="typcn typcn-pen icon"></span>You will learn:</h3>
            <p>Gardening Basics, Terms and "How-To"</p>
            <p>Essencial Tools</p>
            <p>Environmental ways to deal with pests, plant diseases and other problems</p>
            <p>All about our dear Polinators</p>
            <p>Design Ideas</p>
            <img src="https://www.gardendesign.com/pictures/images/650x490Exact_48x0/site_3/asian-style-rock-garden-rock-garden-with-blue-screen-garden-design_15639.jpg" width="450" height="300" alt=""/>
          </div>
          <div class="row">
          <div class="six columns">
            <h3><span class="typcn typcn-cog-outline icon"></span>Our Flowers and Blooms</h3>
            <p>If you've always dreamed of having a gorgeous flower garden, now is the time to make it happen. Starting a flower garden is both fun and rewarding.</p>
            <p>Follow these guidelines and you'll be off to a great start:</p>
            <p>How to Start a Flower Garden; Easy Flowers for beginners; How to grow Annuals, Perennials, Shrubs and Bulbs; Best Indoor Flower; Plant a Hanging Flower Basket; Benefits of a Moon Garden; Orchid Care 101; etc</p>
            <img src="https://www.birdsandblooms.com/wp-content/uploads/2018/01/BNBbyc16_Donna-Blair_002.jpg?resize=768,576" width="450" height="300" alt=""/>
          </div>
          <div class="six columns">
          <br>
            <h3><span class="typcn typcn-lightbulb icon"></span>Our Plants and Herbs</h3>
            <p>Herbs have been grown and used for thousands of years for their culinary and medicinal qualities. Their ornamental and aromatic qualities lend aesthetic beauty and fragrance to any landscape. Once you've tasted the difference between fresh and dried herbs, you'll never go back. Not only are fresh herbs more nutritious and better tasting, they are less expensive to grow and harvest yourself compared to buying them at the grocery store.</p>
            <p>Here are some tips on how to start an herb garden and get growing your own fresh herbs at home:</p>
            <p>How to grow Herbs - Indoors and Outdoors; Easy Herbs to grow; Raised Bed Gardens; All about our dear Polinators; Design Ideas</p>
            <img src="https://gardenplannerwebsites.azureedge.net/blog/jekkas-herb-farm-chelsea-2x.jpg" width="450" height="300" alt=""/>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Polinators Section-->  

  <section id="team">
    <div class="container">
      <div class="row">
        <h1>Meet the Polinators</h1>
        <div class="block"></div>
        <p><b>Why You Should Plant a Pollinator Garden:</b></p>
        <p>Having flower-filled private yards, in addition to natural areas and public gardens with fragrant pollinator favorites, is important. These gardens will provide corridors for these insects to travel, explore and get the resources they need.</p>
        <p>A wide range of tiny creatures—from the showy monarch butterfly to the humble flower fly—is responsible for supporting 85% of the world's flowering plants and helping to keep more than two-thirds of the world's crop species going. In addition, fruits and seeds from pollinated plants are a diet staple for 25% of birds and many mammals.</p>
        <p>While catering to pollinators seems intuitive, a few tips and tricks should make your yard and gardens even more fruitful for all of your flying friends</p>
      </div>
      <div class="row">
        <div class="three columns"> <img src="https://dynaimage.cdn.cnn.com/cnn/c_fill,g_auto,w_1200,h_675,ar_16:9/https%3A%2F%2Fcdn.cnn.com%2Fcnnnext%2Fdam%2Fassets%2F200127163154-bumble-bee-flower-stock.jpg" width="220" height="220" alt=""/>
          <h4><b>Bees</b></h4>
          <p>Bees help your gardens thrive, so treat them well by growing bee-friendly plants. Bee populations are declining rapidly in many regions of the country, with habitat loss being a primary cause. Growing a diverse variety of flowering plants can satisfy the appetites of various bee species. Along with planting lots of flowers that attract bees, we can also improve the environment for bees by creating a safe haven in our gardens that they can call home.</p>
          <p><b>What makes a flower Bee friendly?</b></p>
          <p>It provides a healthy diet. Flowers that attract bees provide abundant nectar and pollen, the only sources of carbohydrates and protein in a bee's diet. It's the right color. They actually see flowers in the blue and purple color spectrum better than other hues and are naturally attracted to them.</p>
          <span class="typcn typcn-social-facebook-circular icon"></span><span class="typcn typcn-social-instagram-circular icon"></span><span class="typcn typcn-social-google-plus-circular icon"></span><span class="typcn typcn-social-linkedin-circular icon"></span> </div>
        <div class="three columns"> <img src="https://www.birdsandblooms.com/wp-content/uploads/2020/07/BNBbyc16_Dan-Davidson-Sr_001.jpg?resize=768,533" width="220" height="220" alt=""/>
          <h4><b>Butterflies</b></h4>
          <p>When it comes to food sources for butterflies, not all plants are created equal. Through evolution, individual butterfly species became highly selective with the types of plants they feed on. While many plant varieties can attract butterflies, some are better than others for providing essential nutrients. Adult butterflies and their offspring differ in the way they consume food. Adults drink through a long tubular tongue, relying solely on liquid sources such as flower nectar, tree sap, and fallen fruit. Butterfly larvae have chewing mouth parts, feeding on leafy food sources such as milkweed foliage, herbs, trees, and grasses</p>
          <p><b>How to select Butterfly-friendly plants?</b></p>
          <p>Include plants that will support butterflies throughout their life cycle. Flowering nectar plants offer food and energy for adults, while the leaves of larval plants such as parsley and milkweed nourish growing caterpillars. Plants that provide both nectar sources for butterflies and caterpillar food are especially valuable. Choose a mix of trees, shrubs, perennials, and annuals.</p>
          <span class="typcn typcn-social-facebook-circular icon"></span><span class="typcn typcn-social-instagram-circular icon"></span><span class="typcn typcn-social-google-plus-circular icon"></span><span class="typcn typcn-social-linkedin-circular icon"></span> </div>
        <div class="three columns"> <img src="https://www.birdsandblooms.com/wp-content/uploads/2021/07/246787571_1_JB_Smith_BNB_Hummingbird_Contest_2020.jpg?resize=768,512" width="220" height="220" alt=""/>
          <h4><b>Hummingbirds</b></h4>
          <p>Is there anything more magical than watching a hummingbird, seemingly suspended in midair, dip its long beak into a flower? Sometimes you'll hear these tiny birds before you see them, their wings making a distinctive whirring sound. When two or more appear together, you may hear the sharp “chattering” as they swoop and dive in a series of aggressive, aerial maneuvers. It's no wonder that gardeners love to encourage these remarkable acrobats into their gardens.</p>
          <p><b>What flowers do hummingbirds like?</b></p>
          <p>Hummingbirds are primarily attracted to long tubular flowers that are red, but are frequently seen visiting flowers that are orange, yellow, purple, or even blue, giving you plenty to choose from. Keep in mind that many double-flowered forms aren't accessible to pollinators.</p>
          <span class="typcn typcn-social-facebook-circular icon"></span><span class="typcn typcn-social-instagram-circular icon"></span><span class="typcn typcn-social-google-plus-circular icon"></span><span class="typcn typcn-social-linkedin-circular icon"></span> </div>
        <div class="three columns"> <img src="https://i.pinimg.com/736x/a1/81/43/a181435b41b2bdbc65a3d56a79ed1435--lady-bugs-tattoo-ideas.jpg" width="220" height="220" alt=""/>
        <h4><b>Ladybugs</b></h4>
        <p>Attracting ladybugs is one of the top wishes for many organic gardeners. Ladybugs in the garden will help to eliminate destructive pests like aphids, mites and scale. Getting ladybugs to come to your garden, and more importantly stay in your garden, is easy once you know a few simple facts and tricks.</p>
        <p><b>How to Attract Ladybugs to the Garden?</b></p>
        <p>There are several pollen plants that ladybugs like. The blooms on these plants normally have flat flowers (like landing pads) and tend to be white or yellow. The other half of getting ladybugs to come to your garden is to make sure they have enough bugs to eat. Another thing you can do to help bring ladybugs to the garden is to eliminate use of insecticides.</p>
        <span class="typcn typcn-social-facebook-circular icon"></span><span class="typcn typcn-social-instagram-circular icon"></span><span class="typcn typcn-social-google-plus-circular icon"></span><span class="typcn typcn-social-linkedin-circular icon"></span> </div>
      </div>
    </div>
  </section>

  <!-- Design Section-->  

  <section id="skills">
    <div class="container">
      <h1>Plant, Grow and Design</h1>
      <div class="block"></div>
      <div class="row">
        <div class="one-third column">
          <h3>Garden Styles</h3>
          <p>From classic to modern, get inspiration and learn about the various garden types. Whether you're trying to discover the right style for your garden, or you've been gardening for years, you'll find these collections inspiring. Browse gardens with strong Asian influences, ones that favor the sleek lines of modern design, or ones that will transport you to the blissful Mediterranean countryside</p>
        </div>
        <div class="one-third column">
          <h3>How to Garden</h3>
          <p>Learn how to plant and care for vegetables, flowers, and more—even if you're a beginning gardener. Gardening is about finding the right combination of sunlight, fertile soil, and water to make your plants thrive. It's also about fulfilling your passion, so select plants you love. Use the resources here as a starting point, and in no time you'll have a beautiful garden, no matter what level of gardening experience you have.</p>
        </div>
        <div class="one-third column">
          <h3>Garden Ideas and Inspiration</h3>
          <p>A garden is never finished—it is a creation that evolves from season-to-season and year-to-year. If a plant outgrows its previous home, or performs less than adequately, they enjoy selecting its replacement. When the seasons change, they enjoy seeing different plants take center stage and when drought or other climatic conditions strike, they enjoy meeting the challenge. Gardeners are always tinkering, always improving, always dreaming.</p>
        </div>
      </div>
      <div class="row">
        <div class="eight columns">
          <div class="progressBar">
            <h4>Gardening Essentials</h4>
            <div class="progressBarContainer">
              <div class="progressBarValue value-90"></div>
            </div>
          </div>
          <div class="progressBar">
            <h4>Container Garden Ideas</h4>
            <div class="progressBarContainer">
              <div class="progressBarValue value-80"></div>
            </div>
          </div>
          <div class="progressBar">
            <h4>Landscape Design - Styles and Tips</h4>
            <div class="progressBarContainer">
              <div class="progressBarValue value-30"></div>
            </div>
          </div>
          <div class="progressBar">
            <h4>Small Garden Design</h4>
            <div class="progressBarContainer">
              <div class="progressBarValue value-70"></div>
            </div>
          </div>
        </div>
        <div class="four columns">
          <img src="https://i.pinimg.com/564x/3c/01/c7/3c01c72d9537ae491a72cd2b04458a26.jpg" width="400" height="300" alt=""/>
        </div>
      </div>
    </div>
  </section>
</template>



<style>
  .mini-card {
    box-shadow: 0px 0px 5px 0px grey;
    margin: 10px;
    border-radius: 20px;
    padding: 10px;
    font-size: small;
  }

  @import url("https://fonts.googleapis.com/css?family=Open+Sans:400,300");

  /* Base Styles */
  html {
    font-size: 62.5%;
  }

  body {
    font-size: 1.5em;
    line-height: 1.6;
    font-weight: 400;
    font-family: 'Open Sans', Helvetica, Arial, sans-serif;
    color: #222;
  }


  /* Grid */  
  .container {
    position: relative;
    width: 100%;
    max-width: 960px;
    margin: 0 auto;
    padding: 0 20px;
    box-sizing: border-box;
  }
  .column, .columns {
    width: 100%;
    float: left;
    box-sizing: border-box;
  }


  /* For devices larger than 400px */
  @media (min-width: 400px) {
    .container {
      width: 85%;
      padding: 0;
    }
  }


  /* For devices larger than 550px */
  @media (min-width: 550px) {
    .container {
      width: 80%;
    }
    .column,  .columns {
      margin-left: 4%;
    }
    .column:first-child,  .columns:first-child {
      margin-left: 0;
    }
    .one.column,  .one.columns {
      width: 4.66666666667%;
    }
    .two.columns {
      width: 13.3333333333%;
    }
    .three.columns {
      width: 22%;
    }
    .four.columns {
      width: 30.6666666667%;
    }
    .five.columns {
      width: 39.3333333333%;
    }
    .six.columns {
      width: 48%;
    }
    .seven.columns {
      width: 56.6666666667%;
    }
    .eight.columns {
      width: 65.3333333333%;
    }
    .nine.columns {
      width: 74.0%;
    }
    .ten.columns {
      width: 82.6666666667%;
    }
    .eleven.columns {
      width: 91.3333333333%;
    }
    .twelve.columns {
      width: 100%;
      margin-left: 0;
    }
    .one-third.column {
      width: 30.6666666667%;
    }
    .two-thirds.column {
      width: 65.3333333333%;
    }
    .one-half.column {
      width: 48%;
    }


    /* Offsets */
    .offset-by-one.column,  .offset-by-one.columns {
      margin-left: 8.66666666667%;
    }
    .offset-by-two.column,  .offset-by-two.columns {
      margin-left: 17.3333333333%;
    }
    .offset-by-three.column,  .offset-by-three.columns {
      margin-left: 26%;
    }
    .offset-by-four.column,  .offset-by-four.columns {
      margin-left: 34.6666666667%;
    }
    .offset-by-five.column,  .offset-by-five.columns {
      margin-left: 43.3333333333%;
    }
    .offset-by-six.column,  .offset-by-six.columns {
      margin-left: 52%;
    }
    .offset-by-seven.column,  .offset-by-seven.columns {
      margin-left: 60.6666666667%;
    }
    .offset-by-eight.column,  .offset-by-eight.columns {
      margin-left: 69.3333333333%;
    }
    .offset-by-nine.column,  .offset-by-nine.columns {
      margin-left: 78.0%;
    }
    .offset-by-ten.column,  .offset-by-ten.columns {
      margin-left: 86.6666666667%;
    }
    .offset-by-eleven.column,  .offset-by-eleven.columns {
      margin-left: 95.3333333333%;
    }
    .offset-by-one-third.column,  .offset-by-one-third.columns {
      margin-left: 34.6666666667%;
    }
    .offset-by-two-thirds.column,  .offset-by-two-thirds.columns {
      margin-left: 69.3333333333%;
    }
    .offset-by-one-half.column,  .offset-by-one-half.columns {
      margin-left: 52%;
    }
  }


  /* Typography */
  h1, h2, h3, h4, h5, h6 {
    margin-top: 0;
    margin-bottom: 2rem;
    font-weight: 300;
  }
  h1 {
    font-size: 4.0rem;
    line-height: 1.2;
    letter-spacing: -.1rem;
  }
  h2 {
    font-size: 3.6rem;
    line-height: 1.25;
    letter-spacing: -.1rem;
  }
  h3 {
    font-size: 3.0rem;
    line-height: 1.3;
    letter-spacing: -.1rem;
  }
  h4 {
    font-size: 2.4rem;
    line-height: 1.35;
    letter-spacing: -.08rem;
  }
  h5 {
    font-size: 1.8rem;
    line-height: 1.5;
    letter-spacing: -.05rem;
  }
  h6 {
    font-size: 1.5rem;
    line-height: 1.6;
    letter-spacing: 0;
  }


  /* Larger than phablet */
  @media (min-width: 550px) {
    h1 {
      font-size: 5.0rem;
    }
    h2 {
      font-size: 4.2rem;
    }
    h3 {
      font-size: 3.6rem;
    }
    h4 {
      font-size: 3.0rem;
    }
    h5 {
      font-size: 2.4rem;
    }
    h6 {
      font-size: 1.5rem;
    }
  }
  p {
    margin-top: 0;
  }


  /* Links */
  a {
    color: #1EAEDB;
  }
  a:hover {
    color: #0FA0CE;
  }


  /* About Section */
  #about {
    padding: 100px 0 50px 0;
  }


  /* Team Section */
  #team {
    padding: 50px 0 100px 0;
  }
  #team .icon {
    font-size: 26px;
  }


  /* Skills Section */
  #skills {
    padding: 100px 0 100px 0;
    background-color: #F5F5F5;
  }
  .progressBar {
    margin-bottom: 26px;
    margin-bottom: 1.66em;
  }
  .progressBar h4 {
    font-size: 16px;
    text-transform: none;
    margin-bottom: 7px;
    margin-bottom: .33em;
  }
  .progressBarContainer {
    width: 100%;
    height: 8px;
    background: #E1E1E1;
    overflow: hidden;
  }
  .progressBarValue {
    height: 8px;
    float: left;
    background: #e55d87; /* Old browsers */
    background: -moz-linear-gradient(-45deg, #e55d87 0%, #5fc3e4 100%);
    background: -webkit-linear-gradient(-45deg, #e55d87 0%, #5fc3e4 100%);
    background: linear-gradient(135deg, #e55d87 0%, #5fc3e4 100%);
  }
  .value-00 {
    width: 0;
  }
  .value-10 {
    width: 10%;
  }
  .value-20 {
    width: 20%;
  }
  .value-30 {
    width: 30%;
  }
  .value-40 {
    width: 40%;
  }
  .value-50 {
    width: 50%;
  }
  .value-60 {
    width: 60%;
  }
  .value-70 {
    width: 70%;
  }
  .value-80 {
    width: 80%;
  }
  .value-90 {
    width: 90%;
  }
  .value-100 {
    width: 100%;
  }


  /* Contact Section*/
  #contact {
    padding: 100px 0 100px 0;
  }
  input[type="email"], input[type="number"], input[type="search"], input[type="text"], input[type="tel"], input[type="url"], input[type="password"], textarea, select {
    height: 38px;
    padding: 6px 10px; /* The 6px vertically centers text on FF, ignored by Webkit */
    background-color: #F5F5F5;
    border: none;
    box-shadow: none;
    box-sizing: border-box;
    border-radius: 0;
    outline: none;
  }
  textarea {
    min-height: 250px;
  }
  input[type="submit"] {
    display: inline-block;
    height: 38px;
    padding: 0 30px;
    color: #fff;
    text-align: center;
    font-size: 11px;
    font-weight: 600;
    line-height: 38px;
    letter-spacing: .1rem;
    text-transform: uppercase;
    text-decoration: none;
    white-space: nowrap;
    background: #5fc3e4;
    border-radius: 0px;
    border: 0;
    cursor: pointer;
    box-sizing: border-box;
  }
  input[type="submit"]:hover {
    background: #e55d87;
    text-decoration: none;
  }


    /* Utilities */
  .u-full-width {
    width: 100%;
    box-sizing: border-box;
  }
  .u-max-full-width {
    max-width: 100%;
    box-sizing: border-box;
  }
  .u-pull-right {
    float: right;
  }
  .u-pull-left {
    float: left;
  }

  /* Clearing */
  .container:after, .row:after, .u-cf {
    content: "";
    display: table;
    clear: both;
  }


  /* Misc */
  .icon {
    padding-right: 10px;
    color: #e55d87;
  }
  .block {
    width: 70px;
    height: 2px;
    background: #e55d87; /* Old browsers */
    background: -moz-linear-gradient(-45deg, #e55d87 0%, #5fc3e4 100%);
    background: -webkit-linear-gradient(-45deg, #e55d87 0%, #5fc3e4 100%);
    background: linear-gradient(135deg, #e55d87 0%, #5fc3e4 100%);
    margin-bottom: 50px;
  }
</style>
