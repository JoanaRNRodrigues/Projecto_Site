<!--HTML e CSS Retirado do site: https://codepen.io/joanarnrodrigues/pen/vYpxGJM-->
<!--Conteudo Retirado do site: https://www.birdsandblooms.com/   e   https://www.gardeningknowhow.com/-->

<template>
    <!-- About Section   -->  
  
  <section id="about">
    <div class="container">
      <div class="row">
        <h1>How to Grow a Pollinator Garden</h1>
        <div class="block"></div>
          <p><b>Follow these simple steps and tips to create a gorgeous pollinator garden that butterflies, bees and birds will love to visit.</b></p>
        </div>
        <div class="row">
          <div class="six columns">
            <h3><span class="typcn typcn-device-desktop icon"></span>Plan Your Pollinator Garden</h3>
            <p>Make a note of which plants seem the most interesting for pollinators and focus on those. If you don't have time to watch and categorize, she suggests visiting your local extension office or its website for recommendations of plants that lend a hand to pollinators.nd ideas!</p>
            <img src="https://www.butchartgardens.com/wp-content/uploads/2019/09/Summer124-1280x854.jpg" width="450" height="270" alt=""/>
          </div>
          <div class="six columns">
            <h3><span class="typcn typcn-pen icon"></span>Grow Plants for All Seasons</h3>
            <p>Mixing flowers with different bloom times also helps your garden stay vibrant continuously throughout the seasons. One recommendation for early spring pollinators is a sand cherry shrub.</p>
            <img src="https://www.gardeningknowhow.com/wp-content/uploads/2007/03/flowers-1.jpg" width="450" height="300" alt=""/>
          </div>
          <div class="row">
          <div class="six columns">
          <br>
            <h3><span class="typcn typcn-cog-outline icon"></span>Replace Grass with Native Plants</h3>
            <p>Consider mowing less frequently so the clover or dandelions have a chance to bloom. If you have an area that can go wild with native plants, let it. Think about reaching out to your local municipality to inquire about planting more flowers in public places or even converting portions of green parkland into spaces for natives.</p>
            <img src="https://www.nps.gov/articles/000/images/1D45C781-E0BB-4AD1-9EE8-1281EDF91969.jpeg" width="450" height="300" alt=""/>
          </div>
          <div class="six columns">
          <br>
            <h3><span class="typcn typcn-lightbulb icon"></span>More Tips to Help Pollinators</h3>
            <p>Leave small rocks on patches of dirt, Scott suggests, for pollinators that nest on the ground.</p>
            <p>Resist the urge to use a weed barrier on your landscape.</p>
            <p>Skip cleaning up any dead stems and twigs on your yard at the end of the growing season. </p>
            <img src="https://www.coreorchards.com/wp-content/uploads/2020/07/Susan-blog-header-pollinators-3.jpg" width="450" height="300" alt=""/>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Polinators Section-->  

  <section id="team">
    <div class="container">
      <div class="row">
        <h1>Attracting the Polinators</h1>
        <div class="block"></div>
      </div>
      <div class="row">
        <div class="three columns"> <img src="https://encouragementforeveryday.files.wordpress.com/2013/09/bumblebee2.jpg" width="220" height="220" alt=""/>
          <h4><b>Help the Bees</b></h4>
          <p>Bees are a big deal. These unsung heroes of the planet work hard to keep our food supply functioning.</p>
          <p><b><u>How to help them?</u></b></p>
          <img src="https://geneticliteracyproject.org/wp-content/uploads/2018/04/hb3.jpg" width="220" height="220" alt=""/>
          <p><u>Avoid Pesticides</u></p>
          <p>This one seems a pretty obvious way gardeners can help bees, right? Of course, it's not always that easy. Sometimes you have to figure out how to battle an infestation of cabbage worms or Japanese beetles. The key here is to treat these problems where and when they happen, rather than applying broad-spectrum pesticides “just in case.” Additionally, choose plants from local nurseries that don’t treat seeds with systemic pesticides, like neonicotinoids. These pesticides are found throughout the entire plant, and can’t be rinsed off. They kill all insects by attacking the central nervous system. Many states require plants treated with systemic pesticides to be marked as such, and you should definitely avoid them whenever you can.</p>
          <img src="https://contentgrid.homedepot-static.com/hdus/en_US/DTCCOMNEW/Articles/plant-perennials-in-a-cut-flower-garden-hero.jpg" width="220" height="220" alt=""/>
          <p><u>Grow Colorful Plants and Flowers</u></p>
          <p>Colorful flowers make your yard pop as nothing else can. They are like an appetizing sight that draws in all kinds of insect life. There are so many beautiful flowers, vegetables, and other plants to choose from.</p>
          <img src="https://cdn.diyncrafts.com/wp-content/uploads/2020/06/edible-wildflowers-plants-weeds.jpg" width="220" height="220" alt=""/>
          <p><u>Be Kind to Weeds</u></p>
          <p>On that same note, don't be too quick to pull or mow weeds. After all, what you consider a “weed” may be a wildflower that bees depend on. Consider leaving a patch of your yard as wild as possible. If space allows, plant a wildflower meadow. Additionally, contact your local government and urge them to consider mowing roadsides and medians less frequently, to allow wildflowers that grow there to thrive. Of course, you do want to control invasive and poisonous plants.</p>
          <span class="typcn typcn-social-facebook-circular icon"></span><span class="typcn typcn-social-instagram-circular icon"></span><span class="typcn typcn-social-google-plus-circular icon"></span><span class="typcn typcn-social-linkedin-circular icon"></span> </div>
        <div class="three columns"> <img src="https://www.birdsandblooms.com/wp-content/uploads/2022/01/BNBugc_DeborahBillings_Original.jpg?resize=768,768" width="220" height="220" alt=""/>
          <h4><b>Attracting Butterflies</b></h4>
          <p>Want to add some winged wonder to your backyard? Attract butterflies with these butterfly gardening ideas and our expert tips on the best plants and flowers that attract butterflies.</p>
          <p><b><u>What do they need?</u></b></p>
          <img src="https://www.birdsandblooms.com/wp-content/uploads/2022/03/painted-lady-buttonbush-scaled.jpg?resize=768,512" width="220" height="220" alt=""/>
          <p><u>Grow Native Plants for Butterflies:</u></p>
          <p>Native plants are the perfect choice for a butterfly garden. They are adapted to the local soils and climate, so you'll spend less money and effort to attract more butterflies in the long run</p>
          <img src="https://www.birdsandblooms.com/wp-content/uploads/2013/12/Butterflies-Connie-Etter.jpg?resize=568,419" width="220" height="220" alt=""/>
          <p><u>Nectar Flowers</u></p>
          <p>Putting in a selection of popular nectar flowers, then getting a good field guide to learn which butterfly species visit them the most. The larger waves of color help draw in butterflies. Include plants of varying heights, and don't neglect shady spots — some butterflies prefer them.</p>
          <img src="https://www.birdsandblooms.com/wp-content/uploads/2022/03/monarch-caterpillar-butterfly-weed-scaled.jpg?resize=768,510" width="220" height="220" alt=""/>
          <p><u>Add Butterfly Host Plants</u></p>
          <p>Once you've identified the butterflies visiting your yard, add the host plants that their caterpillars need. Each species has its own requirements. For instance, monarchs use milkweed, while eastern black swallowtails eat from the parsley family. Once again, native plants reign supreme, so choose local species of milkweed and other host plants for the most success.</p>
          <span class="typcn typcn-social-facebook-circular icon"></span><span class="typcn typcn-social-instagram-circular icon"></span><span class="typcn typcn-social-google-plus-circular icon"></span><span class="typcn typcn-social-linkedin-circular icon"></span> </div>
        <div class="three columns"> <img src="https://www.birdsandblooms.com/wp-content/uploads/2020/08/penstemon_Katherine-Poulsen.jpg?resize=768,512" width="220" height="220" alt=""/>
          <h4><b>Attract Hummingbirds</b></h4>
          <p>Love hummingbirds? Attract them to your backyard with our recommendations on plants and flowers that attract hummingbirds and gardening tips and tricks from our experts.</p>
          <p><b><u>How to attract them?</u></b></p>
          <img src="https://www.birdsandblooms.com/wp-content/uploads/2021/06/248118263_1_Sharon_Sauriol__BNBHC20.jpg?resize=768,512" width="220" height="220" alt=""/>
          <p><u>Plant More Native Plants for Hummingbirds</u></p>
          <p>Native plants act as fantastic hosts for native insects, too. While hummingbirds are known for their nectar needs, they also eat and feed insects to their young.</p>
          <img src="https://www.birdsandblooms.com/wp-content/uploads/2022/02/BBjj17_ClatisTow_R-e1645817013704.jpg?resize=768,776" width="220" height="220" alt=""/>
          <p><u>Add Water and Shelter for Hummingbirds</u></p>
          <p>Like most other birds, hummers are skittish. While they don't perch for long, they like places to hide as they zoom back and forth between hummingbird garden plants and feeders. Because of that, consider a small potted conifer shrub where they can have a quick rest. Many dwarf shrubs can be planted in containers. Hummingbirds also love a water source such as a birdbath for a quick drink or to cool off in the heat of summer. Consider a mister or water feature with a fine spray (keep it off the ground or near a shrub to provide safety from predators). They love both the noise and water movement.</p>
          <img src="https://www.birdsandblooms.com/wp-content/uploads/2015/05/hummingbirdfeeder_rhonda-horrall.jpg?resize=300,300" width="220" height="220" alt=""/>
          <p><u>Get a Sugary-water Feeder</u></p>
          <p>Another popular way to attract hummingbirds to a garden of any size is with a sugar-water feeder. Hummingbirds's needs regarding nectar are so specific and quite regular, so they'll always take advantage of those kinds of resources. feeders should ideally be used in addition to native plants in a hummingbird garden to help fulfill a bird'ss nutritional needs.</p>
          <span class="typcn typcn-social-facebook-circular icon"></span><span class="typcn typcn-social-instagram-circular icon"></span><span class="typcn typcn-social-google-plus-circular icon"></span><span class="typcn typcn-social-linkedin-circular icon"></span> </div>
        <div class="three columns"> <img src="https://worldbirds.com/wp-content/uploads/2020/08/ladybug-symbolism7.jpg" width="220" height="220" alt=""/>
        <h4><b>Keep Ladybugs</b></h4>
        <p>Attracting ladybugs is one of the top wishes for many organic gardeners. Ladybugs in the garden will help to eliminate destructive pests like aphids, mites and scale. Getting ladybugs to come to your garden, and more importantly stay in your garden, is easy once you know a few simple facts and tricks.</p>
        <p><b><u>How to encourage Ladybugs to the Garden?</u></b></p>
        <img src="https://ladybugplanet.com/wp-content/uploads/2018/12/ladybug-survive-water.jpg" width="220" height="220" alt=""/>
        <p><u>Provide a water source</u></p>
        <p>Try leaving out shallow water bowls and damp paper towels so passing ladybugs are tempted to make a pit stop in your garden for a drink. If using water bowls, fill the bowl with small stones up to the water surface so the ladybugs won't drown as they hydrate.</p>
        <img src="https://www.slugabug.com/wp-content/uploads/2012/07/ladybug-4125852_1280.jpg" width="220" height="220" alt=""/>
        <p><u>Provide shelter</u></p>
        <p>Plant low groundcover plants like oregano and thyme in order to provide ladybugs with a protective hideout from predators, such as birds and toads. Mulch and leaves make an effective refuge as well. If you enjoy a DIY project, you can also build a ladybug house to entice these good bugs to stay in your garden. A ladybug house is simply a small wooden box with holes that contains a lure (such as raisins or sugar water) to attract ladybugs. An added bonus of building a ladybug house is that it may attract additional beneficial insects like bees and green lacewings.</p>
        <img src="https://www.palmettoexterminators.net/wp-content/uploads/sites/1/2020/01/shutterstock_1014142717.jpg" width="220" height="220" alt=""/>
        <p><u>Plant decoy plants for aphids</u></p>
        <p>Aphids are a favorite food source for ladybugs and will attract ladybugs to your garden, but you may be wondering: Is it counterproductive to intentionally lure harmful aphids just to provide ladybugs with a delicious snack? While you don't want aphids infesting your main plants, a safe way to attract aphids is to plant decoy plants nearby for aphids to eat instead of your main plants. Effective decoy plants that will attract aphids include nasturtiums, radishes, early cabbages, and marigolds.</p>
        <span class="typcn typcn-social-facebook-circular icon"></span><span class="typcn typcn-social-instagram-circular icon"></span><span class="typcn typcn-social-google-plus-circular icon"></span><span class="typcn typcn-social-linkedin-circular icon"></span> </div>
      </div>
    </div>
  </section>
</template>


<style>
  .mini-card {
    box-shadow: 0px 0px 5px 0px grey;
    margin: 10px;
    border-radius: 20px;
    padding: 10px;
    font-size: small;
  }

  @import url("https://fonts.googleapis.com/css?family=Open+Sans:400,300");

  /* Base Styles */
  html {
    font-size: 62.5%;
  }

  body {
    font-size: 1.5em;
    line-height: 1.6;
    font-weight: 400;
    font-family: 'Open Sans', Helvetica, Arial, sans-serif;
    color: #222;
  }


  /* Grid */  
  .container {
    position: relative;
    width: 100%;
    max-width: 960px;
    margin: 0 auto;
    padding: 0 20px;
    box-sizing: border-box;
  }
  .column, .columns {
    width: 100%;
    float: left;
    box-sizing: border-box;
  }


  /* For devices larger than 400px */
  @media (min-width: 400px) {
    .container {
      width: 85%;
      padding: 0;
    }
  }


  /* For devices larger than 550px */
  @media (min-width: 550px) {
    .container {
      width: 80%;
    }
    .column,  .columns {
      margin-left: 4%;
    }
    .column:first-child,  .columns:first-child {
      margin-left: 0;
    }
    .one.column,  .one.columns {
      width: 4.66666666667%;
    }
    .two.columns {
      width: 13.3333333333%;
    }
    .three.columns {
      width: 22%;
    }
    .four.columns {
      width: 30.6666666667%;
    }
    .five.columns {
      width: 39.3333333333%;
    }
    .six.columns {
      width: 48%;
    }
    .seven.columns {
      width: 56.6666666667%;
    }
    .eight.columns {
      width: 65.3333333333%;
    }
    .nine.columns {
      width: 74.0%;
    }
    .ten.columns {
      width: 82.6666666667%;
    }
    .eleven.columns {
      width: 91.3333333333%;
    }
    .twelve.columns {
      width: 100%;
      margin-left: 0;
    }
    .one-third.column {
      width: 30.6666666667%;
    }
    .two-thirds.column {
      width: 65.3333333333%;
    }
    .one-half.column {
      width: 48%;
    }


    /* Offsets */
    .offset-by-one.column,  .offset-by-one.columns {
      margin-left: 8.66666666667%;
    }
    .offset-by-two.column,  .offset-by-two.columns {
      margin-left: 17.3333333333%;
    }
    .offset-by-three.column,  .offset-by-three.columns {
      margin-left: 26%;
    }
    .offset-by-four.column,  .offset-by-four.columns {
      margin-left: 34.6666666667%;
    }
    .offset-by-five.column,  .offset-by-five.columns {
      margin-left: 43.3333333333%;
    }
    .offset-by-six.column,  .offset-by-six.columns {
      margin-left: 52%;
    }
    .offset-by-seven.column,  .offset-by-seven.columns {
      margin-left: 60.6666666667%;
    }
    .offset-by-eight.column,  .offset-by-eight.columns {
      margin-left: 69.3333333333%;
    }
    .offset-by-nine.column,  .offset-by-nine.columns {
      margin-left: 78.0%;
    }
    .offset-by-ten.column,  .offset-by-ten.columns {
      margin-left: 86.6666666667%;
    }
    .offset-by-eleven.column,  .offset-by-eleven.columns {
      margin-left: 95.3333333333%;
    }
    .offset-by-one-third.column,  .offset-by-one-third.columns {
      margin-left: 34.6666666667%;
    }
    .offset-by-two-thirds.column,  .offset-by-two-thirds.columns {
      margin-left: 69.3333333333%;
    }
    .offset-by-one-half.column,  .offset-by-one-half.columns {
      margin-left: 52%;
    }
  }


  /* Typography */
  h1, h2, h3, h4, h5, h6 {
    margin-top: 0;
    margin-bottom: 2rem;
    font-weight: 300;
  }
  h1 {
    font-size: 4.0rem;
    line-height: 1.2;
    letter-spacing: -.1rem;
  }
  h2 {
    font-size: 3.6rem;
    line-height: 1.25;
    letter-spacing: -.1rem;
  }
  h3 {
    font-size: 3.0rem;
    line-height: 1.3;
    letter-spacing: -.1rem;
  }
  h4 {
    font-size: 2.4rem;
    line-height: 1.35;
    letter-spacing: -.08rem;
  }
  h5 {
    font-size: 1.8rem;
    line-height: 1.5;
    letter-spacing: -.05rem;
  }
  h6 {
    font-size: 1.5rem;
    line-height: 1.6;
    letter-spacing: 0;
  }


  /* Larger than phablet */
  @media (min-width: 550px) {
    h1 {
      font-size: 5.0rem;
    }
    h2 {
      font-size: 4.2rem;
    }
    h3 {
      font-size: 3.6rem;
    }
    h4 {
      font-size: 3.0rem;
    }
    h5 {
      font-size: 2.4rem;
    }
    h6 {
      font-size: 1.5rem;
    }
  }
  p {
    margin-top: 0;
  }


  /* Links */
  a {
    color: #1EAEDB;
  }
  a:hover {
    color: #0FA0CE;
  }


  /* About Section */
  #about {
    padding: 100px 0 50px 0;
  }


  /* Team Section */
  #team {
    padding: 50px 0 100px 0;
  }
  #team .icon {
    font-size: 26px;
  }


  /* Skills Section */
  #skills {
    padding: 100px 0 100px 0;
    background-color: #F5F5F5;
  }
  .progressBar {
    margin-bottom: 26px;
    margin-bottom: 1.66em;
  }
  .progressBar h4 {
    font-size: 16px;
    text-transform: none;
    margin-bottom: 7px;
    margin-bottom: .33em;
  }
  .progressBarContainer {
    width: 100%;
    height: 8px;
    background: #E1E1E1;
    overflow: hidden;
  }
  .progressBarValue {
    height: 8px;
    float: left;
    background: #e55d87; /* Old browsers */
    background: -moz-linear-gradient(-45deg, #e55d87 0%, #5fc3e4 100%);
    background: -webkit-linear-gradient(-45deg, #e55d87 0%, #5fc3e4 100%);
    background: linear-gradient(135deg, #e55d87 0%, #5fc3e4 100%);
  }
  .value-00 {
    width: 0;
  }
  .value-10 {
    width: 10%;
  }
  .value-20 {
    width: 20%;
  }
  .value-30 {
    width: 30%;
  }
  .value-40 {
    width: 40%;
  }
  .value-50 {
    width: 50%;
  }
  .value-60 {
    width: 60%;
  }
  .value-70 {
    width: 70%;
  }
  .value-80 {
    width: 80%;
  }
  .value-90 {
    width: 90%;
  }
  .value-100 {
    width: 100%;
  }


  /* Contact Section*/
  #contact {
    padding: 100px 0 100px 0;
  }
  input[type="email"], input[type="number"], input[type="search"], input[type="text"], input[type="tel"], input[type="url"], input[type="password"], textarea, select {
    height: 38px;
    padding: 6px 10px; /* The 6px vertically centers text on FF, ignored by Webkit */
    background-color: #F5F5F5;
    border: none;
    box-shadow: none;
    box-sizing: border-box;
    border-radius: 0;
    outline: none;
  }
  textarea {
    min-height: 250px;
  }
  input[type="submit"] {
    display: inline-block;
    height: 38px;
    padding: 0 30px;
    color: #fff;
    text-align: center;
    font-size: 11px;
    font-weight: 600;
    line-height: 38px;
    letter-spacing: .1rem;
    text-transform: uppercase;
    text-decoration: none;
    white-space: nowrap;
    background: #5fc3e4;
    border-radius: 0px;
    border: 0;
    cursor: pointer;
    box-sizing: border-box;
  }
  input[type="submit"]:hover {
    background: #e55d87;
    text-decoration: none;
  }


    /* Utilities */
  .u-full-width {
    width: 100%;
    box-sizing: border-box;
  }
  .u-max-full-width {
    max-width: 100%;
    box-sizing: border-box;
  }
  .u-pull-right {
    float: right;
  }
  .u-pull-left {
    float: left;
  }

  /* Clearing */
  .container:after, .row:after, .u-cf {
    content: "";
    display: table;
    clear: both;
  }


  /* Misc */
  .icon {
    padding-right: 10px;
    color: #e55d87;
  }
  .block {
    width: 70px;
    height: 2px;
    background: #e55d87; /* Old browsers */
    background: -moz-linear-gradient(-45deg, #e55d87 0%, #5fc3e4 100%);
    background: -webkit-linear-gradient(-45deg, #e55d87 0%, #5fc3e4 100%);
    background: linear-gradient(135deg, #e55d87 0%, #5fc3e4 100%);
    margin-bottom: 50px;
  }
</style>