<script>
    export default{
        props: {
            error: String,
        },
    }
</script>

<template>          <!-- Melhorar aspetor -->
  <div class="error">
    <br>
    <br>
    <br>
    <br>
    <h1><center>An error has occured!</center></h1>
    <h2><center>Please Try Again</center></h2>
    <br>
    <br>
    <br>
    <br>
  </div>
</template>
